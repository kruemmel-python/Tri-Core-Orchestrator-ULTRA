#!/usr/bin/env bash
# ===============================================
# Tri-Core Orchestrator ULTRA – Linux APU Demo
# ===============================================
# Dieses Skript startet die Demonstration deines
# OpenCL-Treibers unter Linux mit einer APU/CPU.
# Es setzt die nötigen Umgebungsvariablen und
# führt den Testlauf mit function_test.py aus.
# ===============================================

# Aktuelles Verzeichnis bestimmen (robust für Doppelklick/Terminalstart)
cd "$(dirname "$0")"

# Umgebungsvariablen setzen
export CIPHERCORE_DLL="./build/libCC_OpenCl.so"
export CIPHERCORE_GPU=0

echo "==============================================="
echo "🧬 Tri-Core Orchestrator ULTRA – Linux APU Demo"
echo "==============================================="
echo "📂 DLL-Pfad : $CIPHERCORE_DLL"
echo "🎮 GPU-Index: $CIPHERCORE_GPU"
echo

# Sicherheitsprüfung
if [ ! -f "$CIPHERCORE_DLL" ]; then
    echo "❌ Fehler: $CIPHERCORE_DLL nicht gefunden!"
    echo "Bitte stelle sicher, dass die Bibliothek kompiliert wurde."
    exit 1
fi

# Testlauf starten
echo "🚀 Starte Demo-Test..."
python3 function_test.py --bench=none

echo
echo "✅ Demo abgeschlossen."
echo "📊 Wenn vorhanden, siehe 'pca_trajectory.gif' für visuelle Analyse."
echo "==============================================="

